package RMS;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Dao {

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/food_order_system"; // Change this URL as per your setup
    private static final String DB_USERNAME = "root";  // Your DB username
    private static final String DB_PASSWORD = "cse23";      // Your DB password

    // Method to establish the database connection
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
    }

    // Method to get all products
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM products"; // Assuming the table name is 'products'

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int productId = rs.getInt("product_id");
                String productName = rs.getString("product_name");
                double productPrice = rs.getDouble("product_price");
                products.add(new Product(productId, productName, productName, productPrice, productId));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return products;
    }

    // Method to get a product by its ID
    public Product getProductById(int productId) {
        String query = "SELECT * FROM products WHERE product_id = ?";
        Product product = null;

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String productName = rs.getString("product_name");
                double productPrice = rs.getDouble("product_price");
                product = new Product(productId, productName, productName, productPrice, productId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return product;
    }

    // Method to insert a new product
    public boolean addProduct(String productName, double productPrice) {
        String query = "INSERT INTO products (product_name, product_price) VALUES (?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, productName);
            pstmt.setDouble(2, productPrice);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the insert was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;  // Return false if the insert failed
    }

    // Method to update an existing product's details
    public boolean updateProduct(int productId, String productName, double productPrice) {
        String query = "UPDATE products SET product_name = ?, product_price = ? WHERE product_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, productName);
            pstmt.setDouble(2, productPrice);
            pstmt.setInt(3, productId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the update was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;  // Return false if the update failed
    }

    // Method to delete a product
    public boolean deleteProduct(int productId) {
        String query = "DELETE FROM products WHERE product_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, productId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the delete was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;  // Return false if the delete failed
    }
}

