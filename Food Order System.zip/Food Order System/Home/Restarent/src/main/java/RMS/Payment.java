package RMS;

public class Payment {
    private double totalAmount;
    private String paymentMethod;
    private boolean paymentStatus;

    // Constructor
    public Payment(double totalAmount, String paymentMethod) {
        this.totalAmount = totalAmount;
        this.paymentMethod = paymentMethod;
        this.paymentStatus = false;  // Payment status starts as false (not processed)
    }

    // Getters and Setters
    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public boolean isPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(boolean paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    // Method to process payment (this is just a mock for illustration)
    public boolean processPayment() {
        // In a real-world application, this method would interact with a payment gateway (e.g., PayPal, Stripe, etc.)
        System.out.println("Processing payment of $" + totalAmount + " via " + paymentMethod);

        // Simulating payment success (this could be based on actual payment gateway response)
        if (paymentMethod.equals("Credit Card") || paymentMethod.equals("PayPal")) {
            this.paymentStatus = true;  // Payment is successful
            System.out.println("Payment successful.");
        } else {
            this.paymentStatus = false; // Payment failed
            System.out.println("Payment failed. Invalid payment method.");
        }

        return this.paymentStatus;  // Return the payment status (true if successful, false if failed)
    }

    // Method to simulate payment confirmation
    public void confirmPayment() {
        if (this.paymentStatus) {
            System.out.println("Payment confirmed for $" + totalAmount + " via " + paymentMethod);
        } else {
            System.out.println("Payment not confirmed.");
        }
    }

    // Method to simulate refund (if needed)
    public void refundPayment() {
        if (this.paymentStatus) {
            System.out.println("Refunding payment of $" + totalAmount + " via " + paymentMethod);
            this.paymentStatus = false; // Mark as refunded
        } else {
            System.out.println("No payment to refund.");
        }
    }

    // Main method for testing
    public static void main(String[] args) {
        // Creating a payment object with total amount and payment method
        Payment payment = new Payment(100.0, "Credit Card");

        // Process the payment
        boolean paymentSuccess = payment.processPayment();

        // If the payment is successful, confirm it
        if (paymentSuccess) {
            payment.confirmPayment();
        } else {
            System.out.println("Payment failed. Please try again.");
        }

        // Simulate refund after some time
        payment.refundPayment();
    }
}

