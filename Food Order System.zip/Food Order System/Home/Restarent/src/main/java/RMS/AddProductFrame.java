package RMS;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AddProductFrame extends Frame {

    // Declare components for adding a product
    private TextField nameField, descriptionField, priceField;
    private Button addButton, closeButton;

    public AddProductFrame() {
        // Set frame properties
        setTitle("Add Product");
        setSize(400, 300);
        setLayout(new FlowLayout());

        // Create labels and text fields for product details
        Label nameLabel = new Label("Product Name:");
        nameField = new TextField(20);

        Label descriptionLabel = new Label("Description:");
        descriptionField = new TextField(20);

        Label priceLabel = new Label("Price:");
        priceField = new TextField(10);

        // Add components to the frame
        add(nameLabel);
        add(nameField);
        add(descriptionLabel);
        add(descriptionField);
        add(priceLabel);
        add(priceField);

        // Create the Add and Close buttons
        addButton = new Button("Add Product");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addProduct();
            }
        });

        closeButton = new Button("Close");
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);  // Close the AddProductFrame
            }
        });

        // Add buttons to the frame
        add(addButton);
        add(closeButton);

        // Handle window close event
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                setVisible(false);  // Hide the current frame
            }
        });

        setVisible(true);
    }

    // Method to add product to the database
    private void addProduct() {
        String productName = nameField.getText();
        String description = descriptionField.getText();
        String priceText = priceField.getText();

        // Basic validation
        if (productName.isEmpty() || description.isEmpty() || priceText.isEmpty()) {
            showError("All fields must be filled!");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
        } catch (NumberFormatException e) {
            showError("Price must be a valid number!");
            return;
        }

        // Database insertion logic
        try (Connection conn = MyConnection.getConnection()) {
            String sql = "INSERT INTO products (name, description, price) VALUES (?, ?, ?)";
            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, productName);
                pst.setString(2, description);
                pst.setDouble(3, price);

                int rowsAffected = pst.executeUpdate();
                if (rowsAffected > 0) {
                    showSuccess("Product added successfully!");
                    clearFields();  // Clear fields after successful submission
                } else {
                    showError("Failed to add product!");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showError("Database error occurred!");
        }
    }

    // Method to show error message
    private void showError(String message) {
        Dialog errorDialog = new Dialog(this, "Error", true);
        errorDialog.setLayout(new FlowLayout());
        errorDialog.setSize(200, 100);
        errorDialog.add(new Label(message));
        Button okButton = new Button("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                errorDialog.setVisible(false);
            }
        });
        errorDialog.add(okButton);
        errorDialog.setVisible(true);
    }

    // Method to show success message
    private void showSuccess(String message) {
        Dialog successDialog = new Dialog(this, "Success", true);
        successDialog.setLayout(new FlowLayout());
        successDialog.setSize(200, 100);
        successDialog.add(new Label(message));
        Button okButton = new Button("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                successDialog.setVisible(false);
            }
        });
        successDialog.add(okButton);
        successDialog.setVisible(true);
    }

    // Method to clear the input fields
    private void clearFields() {
        nameField.setText("");
        descriptionField.setText("");
        priceField.setText("");
    }

    // Main method to launch the AddProductFrame
    public static void main(String[] args) {
        new AddProductFrame();
    }
}

