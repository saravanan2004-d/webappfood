package RMS;

import java.awt.*;
import java.awt.event.*;

public class Admin extends Frame {
    // Declare components
    Label titleLabel;
    Button viewOrdersButton, updateOrdersButton, deleteOrdersButton;
    TextArea ordersArea;
    Label messageLabel;

    // Sample order data (replace this with real data from a database)
    String[] orders = {
        "Order #1: Pizza - Quantity: 2 - Customer: John Doe - Address: 123 Elm St.",
        "Order #2: Burger - Quantity: 1 - Customer: Jane Smith - Address: 456 Oak Ave.",
        "Order #3: Sushi - Quantity: 3 - Customer: Alice Johnson - Address: 789 Pine Rd.",
        "Order #4: Pasta - Quantity: 1 - Customer: Bob Brown - Address: 101 Maple Dr."
    };

    public Admin() {
        // Set the title and layout
        setTitle("Admin Panel");
        setLayout(new FlowLayout());

        // Initialize components
        titleLabel = new Label("Admin Panel - Order Management");

        viewOrdersButton = new Button("View Orders");
        updateOrdersButton = new Button("Update Orders");
        deleteOrdersButton = new Button("Delete Orders");

        ordersArea = new TextArea(10, 30);
        ordersArea.setEditable(false);

        messageLabel = new Label("");

        // Add components to the frame
        add(titleLabel);
        add(viewOrdersButton);
        add(updateOrdersButton);
        add(deleteOrdersButton);
        add(ordersArea);
        add(messageLabel);

        // Add button event listeners
        viewOrdersButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Display orders in the TextArea
                StringBuilder orderDetails = new StringBuilder();
                for (String order : orders) {
                    orderDetails.append(order).append("\n");
                }
                ordersArea.setText(orderDetails.toString());
                messageLabel.setText("Viewing orders...");
            }
        });

        updateOrdersButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Simulate updating orders
                messageLabel.setText("Update orders functionality is not yet implemented.");
            }
        });

        deleteOrdersButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Simulate deleting orders
                messageLabel.setText("Delete orders functionality is not yet implemented.");
            }
        });

        // Set frame properties
        setSize(450, 350);
        setVisible(true);

        // Add window closing event
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        // Create an instance of Admin
        new Admin();
    }
}
