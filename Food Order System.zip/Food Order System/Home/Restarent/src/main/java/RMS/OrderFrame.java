package RMS;

import java.awt.*;
import java.awt.event.*;

public class OrderFrame extends Frame {

    public OrderFrame() {
        setTitle("Order Food");
        setSize(400, 300);
        setLayout(new FlowLayout());

        // Add content to place orders
        Label label = new Label("Place Your Order Here");
        add(label);

        // Button to place order
        Button orderButton = new Button("Place Order");
        orderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Order placed!");
            }
        });
        add(orderButton);

        // Close button to return to HomeFrame
        Button closeButton = new Button("Close");
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);  // Close the current frame
            }
        });
        add(closeButton);

        // Handle window close event
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                setVisible(false);  // Hide the current frame
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new OrderFrame();
    }
}


