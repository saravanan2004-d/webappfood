package RMS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/food_order_system"; // Update with your DB URL
    private static final String DB_USERNAME = "root";  // Your DB username
    private static final String DB_PASSWORD = "cse23";      // Your DB password

    // Static method to get the database connection
    public static Connection getConnection() throws SQLException {
        try {
            // Ensure that the MySQL JDBC driver is loaded
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("MySQL JDBC Driver not found.");
        }

        // Return the connection to the database
        return DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
    }

    // Method to close the database connection
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
